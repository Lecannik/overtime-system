--
-- PostgreSQL database dump
--

\restrict lbg3d6kB8llJQfHh7EeIpTXBbXKfC5Ea2A2WwDY6xrpX3JFnvfj6D4sVTIXyHtE

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: otptype; Type: TYPE; Schema: public; Owner: overtime_user
--

CREATE TYPE public.otptype AS ENUM (
    'login',
    'password_reset'
);


ALTER TYPE public.otptype OWNER TO overtime_user;

--
-- Name: overtimestatus; Type: TYPE; Schema: public; Owner: overtime_user
--

CREATE TYPE public.overtimestatus AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED',
    'IN_PROGRESS',
    'MANAGER_APPROVED',
    'HEAD_APPROVED',
    'CANCELLED'
);


ALTER TYPE public.overtimestatus OWNER TO overtime_user;

--
-- Name: usercompany; Type: TYPE; Schema: public; Owner: overtime_user
--

CREATE TYPE public.usercompany AS ENUM (
    'Polymedia',
    'AJ-techCom'
);


ALTER TYPE public.usercompany OWNER TO overtime_user;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: overtime_user
--

CREATE TYPE public.userrole AS ENUM (
    'employee',
    'manager',
    'admin',
    'head'
);


ALTER TYPE public.userrole OWNER TO overtime_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: overtime_user
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO overtime_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: overtime_user
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer NOT NULL,
    action character varying NOT NULL,
    target_type character varying,
    target_id integer,
    details json,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO overtime_user;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: overtime_user
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO overtime_user;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: overtime_user
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: overtime_user
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    name character varying NOT NULL,
    head_id integer
);


ALTER TABLE public.departments OWNER TO overtime_user;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: overtime_user
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departments_id_seq OWNER TO overtime_user;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: overtime_user
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: overtime_user
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying NOT NULL,
    message character varying NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.notifications OWNER TO overtime_user;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: overtime_user
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_id_seq OWNER TO overtime_user;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: overtime_user
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: overtimes; Type: TABLE; Schema: public; Owner: overtime_user
--

CREATE TABLE public.overtimes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    project_id integer NOT NULL,
    start_lat double precision,
    start_lng double precision,
    end_lat double precision,
    end_lng double precision,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone,
    description character varying NOT NULL,
    status public.overtimestatus NOT NULL,
    created_at timestamp with time zone NOT NULL,
    manager_approved boolean,
    head_approved boolean,
    manager_comment character varying,
    head_comment character varying,
    location_name character varying,
    voice_url character varying,
    voice_summary character varying,
    approved_hours double precision
);


ALTER TABLE public.overtimes OWNER TO overtime_user;

--
-- Name: overtimes_id_seq; Type: SEQUENCE; Schema: public; Owner: overtime_user
--

CREATE SEQUENCE public.overtimes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.overtimes_id_seq OWNER TO overtime_user;

--
-- Name: overtimes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: overtime_user
--

ALTER SEQUENCE public.overtimes_id_seq OWNED BY public.overtimes.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: overtime_user
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    name character varying NOT NULL,
    manager_id integer,
    weekly_limit integer NOT NULL,
    code character varying(20),
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.projects OWNER TO overtime_user;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: overtime_user
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_id_seq OWNER TO overtime_user;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: overtime_user
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: overtime_user
--

CREATE TABLE public.refresh_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token character varying NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    revoked boolean NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO overtime_user;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: overtime_user
--

CREATE SEQUENCE public.refresh_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.refresh_tokens_id_seq OWNER TO overtime_user;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: overtime_user
--

ALTER SEQUENCE public.refresh_tokens_id_seq OWNED BY public.refresh_tokens.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: overtime_user
--

CREATE TABLE public.system_settings (
    key character varying NOT NULL,
    value character varying NOT NULL
);


ALTER TABLE public.system_settings OWNER TO overtime_user;

--
-- Name: user_otps; Type: TABLE; Schema: public; Owner: overtime_user
--

CREATE TABLE public.user_otps (
    id integer NOT NULL,
    user_id integer NOT NULL,
    code character varying(6) NOT NULL,
    type public.otptype NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.user_otps OWNER TO overtime_user;

--
-- Name: user_otps_id_seq; Type: SEQUENCE; Schema: public; Owner: overtime_user
--

CREATE SEQUENCE public.user_otps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_otps_id_seq OWNER TO overtime_user;

--
-- Name: user_otps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: overtime_user
--

ALTER SEQUENCE public.user_otps_id_seq OWNED BY public.user_otps.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: overtime_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    full_name character varying NOT NULL,
    email character varying NOT NULL,
    hashed_password character varying NOT NULL,
    is_active boolean NOT NULL,
    role public.userrole NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    department_id integer,
    telegram_chat_id character varying,
    notification_level integer DEFAULT 2 NOT NULL,
    must_change_password boolean NOT NULL,
    is_2fa_enabled boolean DEFAULT false NOT NULL,
    company public.usercompany DEFAULT 'Polymedia'::public.usercompany NOT NULL
);


ALTER TABLE public.users OWNER TO overtime_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: overtime_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO overtime_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: overtime_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: overtimes id; Type: DEFAULT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.overtimes ALTER COLUMN id SET DEFAULT nextval('public.overtimes_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('public.refresh_tokens_id_seq'::regclass);


--
-- Name: user_otps id; Type: DEFAULT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.user_otps ALTER COLUMN id SET DEFAULT nextval('public.user_otps_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: overtime_user
--

COPY public.alembic_version (version_num) FROM stdin;
a887b23c45de
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: overtime_user
--

COPY public.audit_logs (id, user_id, action, target_type, target_id, details, created_at) FROM stdin;
1	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-15 12:51:49.60956+00
2	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-16 10:31:06.845082+00
3	1	CREATE_DEPT	department	1	{"name": "\\u0413\\u0418\\u041f"}	2026-05-16 10:34:14.311784+00
4	1	CREATE_DEPT	department	2	{"name": "\\u041c\\u0418\\u041e"}	2026-05-16 10:34:20.456341+00
5	1	CREATE_DEPT	department	3	{"name": "\\u041e\\u041f\\u0420"}	2026-05-16 10:34:31.395947+00
6	1	CREATE_DEPT	department	4	{"name": "\\u041e\\u041f\\u0414"}	2026-05-16 10:35:20.052801+00
7	1	UPDATE_DEPT	department	2	{"name": "\\u041c\\u0418\\u041e-\\u0410\\u0441\\u0442\\u0430\\u043d\\u0430"}	2026-05-16 10:36:07.892365+00
8	1	CREATE_DEPT	department	5	{"name": "\\u041c\\u0422\\u041e - \\u0410\\u043b\\u043c\\u0430\\u0442\\u044b"}	2026-05-16 10:37:41.867334+00
9	1	CREATE_DEPT	department	6	{"name": "\\u0422\\u0435\\u0445\\u043d\\u0438\\u0447\\u0435\\u0441\\u043a\\u0438\\u0439 \\u043e\\u0442\\u0434\\u0435\\u043b"}	2026-05-16 10:38:11.993096+00
10	1	IMPORT_USER_MS	user	0	{"email": "a.ashimov@polymedia.kz"}	2026-05-16 10:43:15.223523+00
11	1	IMPORT_USER_MS	user	0	{"email": "admin@plmkz.onmicrosoft.com"}	2026-05-16 10:43:15.413261+00
12	1	IMPORT_USER_MS	user	0	{"email": "baltabekova@polymedia.kz"}	2026-05-16 10:43:15.607992+00
13	1	IMPORT_USER_MS	user	0	{"email": "baskakov@polymedia.kz"}	2026-05-16 10:43:15.794376+00
14	1	IMPORT_USER_MS	user	0	{"email": "chmil@polymedia.kz"}	2026-05-16 10:43:15.980271+00
15	1	IMPORT_USER_MS	user	0	{"email": "d.khamzin@polymedia.kz"}	2026-05-16 10:43:16.166591+00
16	1	IMPORT_USER_MS	user	0	{"email": "dmitriyev@polymedia.kz"}	2026-05-16 10:43:16.356397+00
17	1	IMPORT_USER_MS	user	0	{"email": "dochshanov@polymedia.kz"}	2026-05-16 10:43:16.548154+00
18	1	IMPORT_USER_MS	user	0	{"email": "dolzhenko@polymedia.kz"}	2026-05-16 10:43:16.737451+00
19	1	IMPORT_USER_MS	user	0	{"email": "drylev@polymedia.kz"}	2026-05-16 10:43:16.930788+00
20	1	IMPORT_USER_MS	user	0	{"email": "dubinin@polymedia.kz"}	2026-05-16 10:43:17.119396+00
21	1	IMPORT_USER_MS	user	0	{"email": "ibragimova@polymedia.kz"}	2026-05-16 10:43:17.307243+00
22	1	IMPORT_USER_MS	user	0	{"email": "ibrayev@polymedia.kz"}	2026-05-16 10:43:17.499748+00
23	1	IMPORT_USER_MS	user	0	{"email": "igembekov@polymedia.kz"}	2026-05-16 10:43:17.692327+00
24	1	IMPORT_USER_MS	user	0	{"email": "kabdeshov@polymedia.kz"}	2026-05-16 10:43:17.887249+00
25	1	IMPORT_USER_MS	user	0	{"email": "kazkenuly@polymedia.kz"}	2026-05-16 10:43:18.075492+00
26	1	IMPORT_USER_MS	user	0	{"email": "khorolskaya@polymedia.kz"}	2026-05-16 10:43:18.269802+00
27	1	IMPORT_USER_MS	user	0	{"email": "kulakhmetova@polymedia.kz"}	2026-05-16 10:43:18.465362+00
28	1	IMPORT_USER_MS	user	0	{"email": "litvinova@polymedia.kz"}	2026-05-16 10:43:18.655114+00
29	1	IMPORT_USER_MS	user	0	{"email": "magay@polymedia.kz"}	2026-05-16 10:43:18.841391+00
30	1	IMPORT_USER_MS	user	0	{"email": "makash@polymedia.kz"}	2026-05-16 10:43:19.027202+00
31	1	IMPORT_USER_MS	user	0	{"email": "mukhazhan@polymedia.kz"}	2026-05-16 10:43:19.212977+00
32	1	IMPORT_USER_MS	user	0	{"email": "n.abdrakhman@polymedia.kz"}	2026-05-16 10:43:19.398731+00
33	1	IMPORT_USER_MS	user	0	{"email": "nabiev@polymedia.kz"}	2026-05-16 10:43:19.590371+00
34	1	IMPORT_USER_MS	user	0	{"email": "pronchenko@polymedia.kz"}	2026-05-16 10:43:19.780617+00
35	1	IMPORT_USER_MS	user	0	{"email": "prosvirin@polymedia.kz"}	2026-05-16 10:43:19.972695+00
36	1	IMPORT_USER_MS	user	0	{"email": "raibekov@polymedia.kz"}	2026-05-16 10:43:20.161593+00
37	1	IMPORT_USER_MS	user	0	{"email": "savchenko@polymedia.kz"}	2026-05-16 10:43:20.347014+00
38	1	IMPORT_USER_MS	user	0	{"email": "shadayev@polymedia.kz"}	2026-05-16 10:43:20.533895+00
39	1	IMPORT_USER_MS	user	0	{"email": "shvetsov@polymedia.kz"}	2026-05-16 10:43:20.732983+00
40	1	IMPORT_USER_MS	user	0	{"email": "sidorenko@polymedia.kz"}	2026-05-16 10:43:20.924452+00
41	1	IMPORT_USER_MS	user	0	{"email": "skoblikov@polymedia.kz"}	2026-05-16 10:43:21.10956+00
42	1	IMPORT_USER_MS	user	0	{"email": "Teregulova@polymedia.kz"}	2026-05-16 10:43:21.295659+00
43	1	IMPORT_USER_MS	user	0	{"email": "urazbakov@polymedia.kz"}	2026-05-16 10:43:21.480242+00
44	1	IMPORT_USER_MS	user	0	{"email": "yenjiyevskiy@polymedia.kz"}	2026-05-16 10:43:21.6694+00
45	1	IMPORT_USER_MS	user	0	{"email": "zabolotskikh@polymedia.kz"}	2026-05-16 10:43:21.860062+00
46	1	IMPORT_USER_MS	user	0	{"email": "zhanpeisov@polymedia.kz"}	2026-05-16 10:43:22.047791+00
47	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-16 10:48:18.837001+00
48	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-16 11:19:41.247951+00
49	1	CREATE_DEPT	department	7	{"name": "\\u041e\\u0442\\u0434\\u0435\\u043b \\u043f\\u0440\\u043e\\u0434\\u0430\\u0436"}	2026-05-16 11:21:09.248257+00
50	6	PASSWORD_RESET	\N	\N	null	2026-05-16 12:03:20.337765+00
51	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-16 12:03:25.956417+00
52	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-16 12:10:41.064311+00
53	1	UPDATE_USER	user	3	{"full_name": "Nikita Chmil (Admin)", "email": "admin@plmkz.onmicrosoft.com", "role": "admin", "department_id": 6, "company": "Polymedia"}	2026-05-16 12:11:12.303766+00
54	1	UPDATE_USER	user	1	{"full_name": "System Administrator", "email": "admin@example.com", "role": "admin", "department_id": 6, "company": "Polymedia"}	2026-05-16 12:11:26.426377+00
55	1	CREATE_DEPT	department	8	{"name": "\\u041a\\u043e\\u043c\\u043c\\u0435\\u0440\\u0447\\u0435\\u0441\\u043a\\u0438\\u0439 \\u043e\\u0442\\u0434\\u0435\\u043b"}	2026-05-16 12:13:12.756219+00
56	1	UPDATE_USER	user	2	{"full_name": "\\u0410\\u0448\\u0438\\u043c\\u043e\\u0432 \\u0410\\u0441\\u0445\\u0430\\u0442 \\u0425\\u0430\\u043b\\u0438\\u043c\\u0443\\u043b\\u0438\\u0435\\u0432\\u0438\\u0447", "email": "a.ashimov@polymedia.kz", "role": "head", "department_id": 7, "company": "Polymedia"}	2026-05-16 12:25:54.940247+00
57	1	UPDATE_USER	user	4	{"full_name": "\\u0411\\u0430\\u043b\\u0442\\u0430\\u0431\\u0435\\u043a\\u043e\\u0432\\u0430 \\u041c\\u0435\\u0440\\u0435\\u0439 \\u041a\\u0430\\u0431\\u0438\\u0431\\u043e\\u043b\\u043b\\u0430\\u0435\\u0432\\u043d\\u0430", "email": "baltabekova@polymedia.kz", "role": "employee", "department_id": 8, "company": "Polymedia"}	2026-05-16 12:26:03.088246+00
58	1	UPDATE_USER	user	5	{"full_name": "\\u0411\\u0430\\u0441\\u043a\\u0430\\u043a\\u043e\\u0432 \\u0412\\u0438\\u0442\\u0430\\u043b\\u0438\\u0439", "email": "baskakov@polymedia.kz", "role": "employee", "department_id": 7, "company": "Polymedia"}	2026-05-16 12:26:11.384758+00
59	1	UPDATE_USER	user	6	{"full_name": "\\u0427\\u043c\\u0438\\u043b\\u044c \\u041d\\u0438\\u043a\\u0438\\u0442\\u0430 \\u041f\\u0430\\u0432\\u043b\\u043e\\u0432\\u0438\\u0447", "email": "chmil@polymedia.kz", "role": "employee", "department_id": 3, "company": "Polymedia"}	2026-05-16 12:26:19.695994+00
60	1	UPDATE_USER	user	7	{"full_name": "\\u0425\\u0430\\u043c\\u0437\\u0438\\u043d \\u0414\\u0430\\u0443\\u0440\\u0435\\u043d\\u00a0\\u0421\\u0435\\u043c\\u0438\\u0433\\u0430\\u0437\\u044b\\u0435\\u0432\\u0438\\u0447", "email": "d.khamzin@polymedia.kz", "role": "employee", "department_id": 8, "company": "Polymedia"}	2026-05-16 12:26:31.021787+00
61	1	UPDATE_USER	user	8	{"full_name": "\\u0414\\u043c\\u0438\\u0442\\u0440\\u0438\\u0435\\u0432 \\u0410\\u0440\\u0442\\u0451\\u043c", "email": "dmitriyev@polymedia.kz", "role": "employee", "department_id": 5, "company": "Polymedia"}	2026-05-16 12:26:42.0787+00
62	1	UPDATE_USER	user	9	{"full_name": "\\u0414\\u043e\\u0449\\u0430\\u043d\\u043e\\u0432 \\u0420\\u0443\\u0441\\u043b\\u0430\\u043d \\u0410\\u0441\\u043a\\u0430\\u0440\\u043e\\u0432\\u0438\\u0447", "email": "dochshanov@polymedia.kz", "role": "employee", "department_id": 3, "company": "Polymedia"}	2026-05-16 12:26:49.349368+00
63	1	UPDATE_USER	user	38	{"full_name": "\\u0422\\u0438\\u043c\\u0443\\u0440 \\u0416\\u0430\\u043d\\u043f\\u0435\\u0439\\u0441\\u043e\\u0432", "email": "zhanpeisov@polymedia.kz", "role": "employee", "department_id": 2, "company": "Polymedia"}	2026-05-16 12:27:06.499386+00
64	1	UPDATE_USER	user	7	{"full_name": "\\u0425\\u0430\\u043c\\u0437\\u0438\\u043d \\u0414\\u0430\\u0443\\u0440\\u0435\\u043d\\u00a0\\u0421\\u0435\\u043c\\u0438\\u0433\\u0430\\u0437\\u044b\\u0435\\u0432\\u0438\\u0447", "email": "d.khamzin@polymedia.kz", "role": "head", "department_id": 8, "company": "Polymedia"}	2026-05-16 12:27:16.111182+00
65	1	UPDATE_USER	user	5	{"full_name": "\\u0411\\u0430\\u0441\\u043a\\u0430\\u043a\\u043e\\u0432 \\u0412\\u0438\\u0442\\u0430\\u043b\\u0438\\u0439", "email": "baskakov@polymedia.kz", "role": "head", "department_id": 7, "company": "Polymedia"}	2026-05-16 12:27:24.216168+00
66	1	UPDATE_USER	user	6	{"full_name": "\\u0427\\u043c\\u0438\\u043b\\u044c \\u041d\\u0438\\u043a\\u0438\\u0442\\u0430 \\u041f\\u0430\\u0432\\u043b\\u043e\\u0432\\u0438\\u0447", "email": "chmil@polymedia.kz", "role": "head", "department_id": 3, "company": "Polymedia"}	2026-05-16 12:27:30.973267+00
67	1	UPDATE_USER	user	10	{"full_name": "\\u0421\\u0442\\u0430\\u043d\\u0438\\u0441\\u043b\\u0430\\u0432 \\u0412\\u043b\\u0430\\u0434\\u0438\\u043c\\u0438\\u0440\\u043e\\u0432\\u0438\\u0447 \\u0414\\u043e\\u043b\\u0436\\u0435\\u043d\\u043a\\u043e", "email": "dolzhenko@polymedia.kz", "role": "employee", "department_id": 6, "company": "Polymedia"}	2026-05-16 12:27:56.517237+00
68	1	UPDATE_USER	user	11	{"full_name": "\\u0412\\u043b\\u0430\\u0434\\u0438\\u043c\\u0438\\u0440 \\u0414\\u0440\\u044b\\u043b\\u0435\\u0432", "email": "drylev@polymedia.kz", "role": "manager", "department_id": 7, "company": "Polymedia"}	2026-05-16 12:28:21.018423+00
69	1	UPDATE_USER	user	12	{"full_name": "\\u0414\\u0443\\u0431\\u0438\\u043d\\u0438\\u043d \\u0412\\u043b\\u0430\\u0434\\u0438\\u043c\\u0438\\u0440 \\u0418\\u0432\\u0430\\u043d\\u043e\\u0432\\u0438\\u0447", "email": "dubinin@polymedia.kz", "role": "head", "department_id": 2, "company": "Polymedia"}	2026-05-16 12:28:31.875259+00
70	1	UPDATE_USER	user	13	{"full_name": "\\u0410\\u0440\\u0443\\u0436\\u0430\\u043d \\u0422\\u043e\\u0439\\u0431\\u043e\\u043b\\u043e\\u0432\\u043d\\u0430 \\u0418\\u0431\\u0440\\u0430\\u0433\\u0438\\u043c\\u043e\\u0432\\u0430", "email": "ibragimova@polymedia.kz", "role": "employee", "department_id": 8, "company": "Polymedia"}	2026-05-16 12:28:42.098589+00
71	1	UPDATE_USER	user	14	{"full_name": "\\u0418\\u0431\\u0440\\u0430\\u0435\\u0432 \\u0410\\u0439\\u0434\\u0430\\u0440 \\u0415\\u0440\\u0431\\u043e\\u043b\\u043e\\u0432\\u0438\\u0447", "email": "ibrayev@polymedia.kz", "role": "employee", "department_id": 7, "company": "Polymedia"}	2026-05-16 12:28:52.840475+00
72	1	UPDATE_USER	user	15	{"full_name": "\\u0418\\u0433\\u0438\\u043c\\u0431\\u0435\\u043a\\u043e\\u0432 \\u041d\\u0443\\u0440\\u043b\\u0430\\u043d \\u0411\\u0443\\u043b\\u0430\\u0442\\u043e\\u0432\\u0438\\u0447", "email": "igembekov@polymedia.kz", "role": "employee", "department_id": 5, "company": "Polymedia"}	2026-05-16 12:29:01.505472+00
73	1	UPDATE_USER	user	16	{"full_name": "\\u041a\\u0430\\u0431\\u0434\\u0435\\u0448\\u043e\\u0432 \\u0417\\u0430\\u043c\\u0438\\u0440", "email": "kabdeshov@polymedia.kz", "role": "manager", "department_id": 7, "company": "Polymedia"}	2026-05-16 12:29:39.69201+00
74	1	UPDATE_USER	user	37	{"full_name": "\\u0417\\u0430\\u0431\\u043e\\u043b\\u043e\\u0442\\u0441\\u043a\\u0438\\u0445 \\u0412\\u044f\\u0447\\u0435\\u0441\\u043b\\u0430\\u0432", "email": "zabolotskikh@polymedia.kz", "role": "employee", "department_id": 1, "company": "Polymedia"}	2026-05-16 12:29:50.742042+00
75	1	UPDATE_USER	user	36	{"full_name": "\\u0415\\u043d\\u0434\\u0436\\u0438\\u0435\\u0432\\u0441\\u043a\\u0438\\u0439 \\u042e\\u0440\\u0438\\u0439 \\u0418\\u0433\\u043e\\u0440\\u0435\\u0432\\u0438\\u0447", "email": "yenjiyevskiy@polymedia.kz", "role": "employee", "department_id": 1, "company": "Polymedia"}	2026-05-16 12:30:02.175827+00
76	1	UPDATE_USER	user	17	{"full_name": "\\u0416\\u0430\\u043d\\u0431\\u043e\\u043b\\u0430\\u0442 \\u041a\\u0430\\u0437\\u043a\\u0435\\u043d\\u0443\\u043b\\u044b", "email": "kazkenuly@polymedia.kz", "role": "manager", "department_id": 7, "company": "Polymedia"}	2026-05-16 12:30:11.829472+00
77	1	UPDATE_USER	user	20	{"full_name": "\\u0410\\u043d\\u0430\\u0441\\u0442\\u0430\\u0441\\u0438\\u044f \\u0410\\u043b\\u0435\\u043a\\u0441\\u0430\\u043d\\u0434\\u0440\\u043e\\u0432\\u043d\\u0430 \\u041b\\u0438\\u0442\\u0432\\u0438\\u043d\\u043e\\u0432\\u0430", "email": "litvinova@polymedia.kz", "role": "employee", "department_id": 6, "company": "Polymedia"}	2026-05-16 12:30:46.099212+00
78	1	UPDATE_USER	user	21	{"full_name": "\\u0420\\u043e\\u043c\\u0430\\u043d \\u041c\\u0430\\u0433\\u0430\\u0439", "email": "magay@polymedia.kz", "role": "employee", "department_id": 1, "company": "Polymedia"}	2026-05-16 12:30:56.545107+00
79	1	UPDATE_USER	user	18	{"full_name": "\\u041a\\u0440\\u0438\\u0441\\u0442\\u0438\\u043d\\u0430 \\u0425\\u043e\\u0440\\u043e\\u043b\\u044c\\u0441\\u043a\\u0430\\u044f", "email": "khorolskaya@polymedia.kz", "role": "employee", "department_id": 8, "company": "Polymedia"}	2026-05-16 12:31:05.843805+00
80	1	UPDATE_USER	user	19	{"full_name": "\\u041a\\u0443\\u043b\\u0430\\u0445\\u043c\\u0435\\u0442\\u043e\\u0432\\u0430 \\u0415\\u043b\\u0435\\u043d\\u0430 \\u0410\\u043d\\u0430\\u0442\\u043e\\u043b\\u044c\\u0435\\u0432\\u043d\\u0430", "email": "kulakhmetova@polymedia.kz", "role": "employee", "department_id": 8, "company": "Polymedia"}	2026-05-16 12:31:12.337613+00
81	1	UPDATE_USER	user	22	{"full_name": "\\u0414\\u0443\\u043b\\u0430\\u0442 \\u041c\\u0430\\u049b\\u0430\\u0448", "email": "makash@polymedia.kz", "role": "employee", "department_id": 7, "company": "Polymedia"}	2026-05-16 12:31:23.367707+00
82	1	UPDATE_USER	user	23	{"full_name": "\\u041c\\u0443\\u0445\\u0430\\u0436\\u0430\\u043d \\u0425\\u0430\\u043c\\u0438\\u0442\\u0445\\u0430\\u043d", "email": "mukhazhan@polymedia.kz", "role": "employee", "department_id": 4, "company": "Polymedia"}	2026-05-16 12:31:32.561482+00
83	1	UPDATE_USER	user	25	{"full_name": "\\u041d\\u0430\\u0431\\u0438\\u0435\\u0432 \\u041c\\u0430\\u0433\\u0436\\u0430\\u043d \\u0411\\u043e\\u043b\\u0430\\u0442\\u0431\\u0435\\u043a\\u0443\\u043b\\u044b", "email": "nabiev@polymedia.kz", "role": "manager", "department_id": 7, "company": "Polymedia"}	2026-05-16 12:31:42.607542+00
84	1	UPDATE_USER	user	24	{"full_name": "\\u041d\\u0443\\u0440\\u0430\\u043b\\u044b \\u0410\\u0431\\u0434\\u0440\\u0430\\u0445\\u043c\\u0430\\u043d", "email": "n.abdrakhman@polymedia.kz", "role": "manager", "department_id": 7, "company": "Polymedia"}	2026-05-16 12:31:56.162213+00
85	1	UPDATE_USER	user	26	{"full_name": "\\u041f\\u0440\\u043e\\u043d\\u0447\\u0435\\u043d\\u043a\\u043e \\u0421\\u0435\\u0440\\u0433\\u0435\\u0439 \\u0412\\u0438\\u043a\\u0442\\u043e\\u0440\\u043e\\u0432\\u0438\\u0447", "email": "pronchenko@polymedia.kz", "role": "manager", "department_id": 7, "company": "Polymedia"}	2026-05-16 12:32:09.699827+00
86	1	UPDATE_USER	user	28	{"full_name": "\\u0420\\u0430\\u0439\\u0431\\u0435\\u043a\\u043e\\u0432 \\u041c\\u0430\\u043a\\u0441\\u0430\\u0442", "email": "raibekov@polymedia.kz", "role": "employee", "department_id": 2, "company": "Polymedia"}	2026-05-16 12:32:21.336825+00
87	1	UPDATE_USER	user	27	{"full_name": "\\u041f\\u0440\\u043e\\u0441\\u0432\\u0438\\u0440\\u0438\\u043d \\u042e\\u0440\\u0438\\u0439 \\u041f\\u0435\\u0442\\u0440\\u043e\\u0432\\u0438\\u0447", "email": "prosvirin@polymedia.kz", "role": "head", "department_id": 1, "company": "Polymedia"}	2026-05-16 12:32:30.087825+00
99	1	UPDATE_DEPT	department	4	{"head_id": 32}	2026-05-16 12:34:21.502122+00
88	1	UPDATE_USER	user	29	{"full_name": "\\u0421\\u0430\\u0432\\u0447\\u0435\\u043d\\u043a\\u043e \\u0412\\u0438\\u043a\\u0442\\u043e\\u0440 \\u0413\\u0435\\u043d\\u043d\\u0430\\u0434\\u044c\\u0435\\u0432\\u0438\\u0447", "email": "savchenko@polymedia.kz", "role": "employee", "department_id": 2, "company": "Polymedia"}	2026-05-16 12:32:40.647895+00
89	1	UPDATE_USER	user	30	{"full_name": "\\u0428\\u0430\\u0434\\u0430\\u0435\\u0432 \\u0411\\u0430\\u0443\\u0440\\u0436\\u0430\\u043d \\u041c\\u0443\\u0440\\u0430\\u0442\\u0431\\u0435\\u043a\\u043e\\u0432\\u0438\\u0447", "email": "shadayev@polymedia.kz", "role": "manager", "department_id": 7, "company": "Polymedia"}	2026-05-16 12:32:50.115572+00
90	1	UPDATE_USER	user	35	{"full_name": "\\u0423\\u0440\\u0430\\u0437\\u0431\\u0430\\u043a\\u043e\\u0432 \\u0416\\u0430\\u043d\\u0431\\u043e\\u043b\\u0430\\u0442 \\u0422\\u0443\\u0440\\u0433\\u0430\\u043d\\u043e\\u0432\\u0438\\u0447", "email": "urazbakov@polymedia.kz", "role": "head", "department_id": 5, "company": "Polymedia"}	2026-05-16 12:32:58.594605+00
91	1	UPDATE_USER	user	34	{"full_name": "\\u0422\\u0435\\u0440\\u0435\\u0433\\u0443\\u043b\\u043e\\u0432\\u0430 \\u0420\\u0435\\u0433\\u0438\\u043d\\u0430", "email": "Teregulova@polymedia.kz", "role": "employee", "department_id": 4, "company": "Polymedia"}	2026-05-16 12:33:08.873406+00
92	1	UPDATE_USER	user	33	{"full_name": "\\u0421\\u043a\\u043e\\u0431\\u043b\\u0438\\u043a\\u043e\\u0432 \\u0412\\u044f\\u0447\\u0435\\u0441\\u043b\\u0430\\u0432 \\u0421\\u0435\\u0440\\u0433\\u0435\\u0435\\u0432\\u0438\\u0447", "email": "skoblikov@polymedia.kz", "role": "employee", "department_id": 1, "company": "Polymedia"}	2026-05-16 12:33:17.03801+00
93	1	UPDATE_USER	user	31	{"full_name": "\\u0428\\u0432\\u0435\\u0446\\u043e\\u0432 \\u0415\\u0433\\u043e\\u0440 \\u0421\\u0435\\u0440\\u0433\\u0435\\u0435\\u0432\\u0438\\u0447", "email": "shvetsov@polymedia.kz", "role": "employee", "department_id": 1, "company": "Polymedia"}	2026-05-16 12:33:29.915932+00
94	1	UPDATE_USER	user	32	{"full_name": "\\u0421\\u0438\\u0434\\u043e\\u0440\\u0435\\u043d\\u043a\\u043e \\u0421\\u0435\\u0440\\u0433\\u0435\\u0439 \\u0410\\u043b\\u0435\\u043a\\u0441\\u0430\\u043d\\u0434\\u0440\\u043e\\u0432\\u0438\\u0447", "email": "sidorenko@polymedia.kz", "role": "head", "department_id": 4, "company": "Polymedia"}	2026-05-16 12:33:41.521878+00
95	1	UPDATE_DEPT	department	2	{"head_id": 12}	2026-05-16 12:34:03.115535+00
96	1	UPDATE_DEPT	department	3	{"head_id": 6}	2026-05-16 12:34:07.550827+00
97	1	UPDATE_DEPT	department	6	{"head_id": 5}	2026-05-16 12:34:11.576159+00
98	1	UPDATE_DEPT	department	1	{"head_id": 27}	2026-05-16 12:34:14.501954+00
100	1	UPDATE_DEPT	department	5	{"head_id": 35}	2026-05-16 12:34:25.024233+00
101	1	UPDATE_DEPT	department	8	{"head_id": 7}	2026-05-16 12:34:33.791496+00
102	1	UPDATE_DEPT	department	7	{"head_id": 2}	2026-05-16 12:34:44.929206+00
103	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-16 12:42:45.190158+00
104	1	CREATE_PROJECT	project	2	{"name": "Net Solution \\u0414\\u0443\\u0448\\u0430\\u043d\\u0431\\u0435"}	2026-05-16 12:43:15.5026+00
105	1	UPDATE_PROJECT	project	2	{"manager_id": 16}	2026-05-16 12:43:24.066904+00
106	1	CREATE_PROJECT	project	3	{"name": "\\u0421\\u041a \\u0424\\u043e\\u0440\\u043c\\u0430\\u0446\\u0438\\u044f"}	2026-05-16 12:43:43.45266+00
107	1	RESET_PASSWORD	user	6	null	2026-05-16 12:44:26.005425+00
108	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-16 12:45:12.588445+00
109	6	CHANGE_PASSWORD	\N	\N	null	2026-05-16 12:45:27.728243+00
110	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-16 12:45:36.536016+00
111	1	UPDATE_PROJECT	project	2	{"name": "\\u041e\\u041e\\u041e \\"\\u041d\\u0435\\u0442 \\u0421\\u043e\\u043b\\u044e\\u0448\\u0435\\u043d\\u0441\\"_\\u0421\\u0426 \\u0414\\u0443\\u0448\\u0430\\u043d\\u0431\\u0435"}	2026-05-16 12:47:44.878152+00
112	1	CREATE_PROJECT	project	4	{"name": "\\u0414\\u0435\\u043f\\u0430\\u0440\\u0442\\u0430\\u043c\\u0435\\u043d\\u0442 \\u043f\\u043e\\u043b\\u0438\\u0446\\u0438\\u0438 \\u0410\\u0442\\u044b\\u0440\\u0430\\u0443\\u0441\\u043a\\u043e\\u0439 \\u043e\\u0431\\u043b\\u0430\\u0441\\u0442\\u0438 \\u041c\\u0412\\u0414 \\u0420\\u041a \\u0413\\u0423_\\u0426\\u041e\\u0423"}	2026-05-16 12:51:08.751417+00
113	1	UPDATE_PROJECT	project	4	{"manager_id": 25}	2026-05-16 12:51:12.546758+00
114	1	REVIEW_ADMIN	overtime	1	{"approved": true, "comment": "\\u041e\\u0434\\u043e\\u0431\\u0440\\u0435\\u043d\\u043e \\u0430\\u0434\\u043c\\u0438\\u043d\\u0438\\u0441\\u0442\\u0440\\u0430\\u0442\\u043e\\u0440\\u043e\\u043c", "new_status": "APPROVED", "as_role": null, "description": "\\u0442\\u0435\\u0441\\u0442", "requested_hours": 11.0, "raw_hours_exact": 10.983333333333333, "approved_hours": 11.0}	2026-05-16 13:04:47.281088+00
115	1	REVIEW_ADMIN	overtime	1	{"approved": true, "comment": "\\u041e\\u0434\\u043e\\u0431\\u0440\\u0435\\u043d\\u043e \\u0430\\u0434\\u043c\\u0438\\u043d\\u0438\\u0441\\u0442\\u0440\\u0430\\u0442\\u043e\\u0440\\u043e\\u043c", "new_status": "APPROVED", "as_role": null, "description": "\\u0442\\u0435\\u0441\\u0442", "requested_hours": 11.0, "raw_hours_exact": 10.983333333333333, "approved_hours": 11.0}	2026-05-16 13:04:49.488512+00
116	1	REVIEW_ADMIN	overtime	1	{"approved": true, "comment": "\\u041e\\u0434\\u043e\\u0431\\u0440\\u0435\\u043d\\u043e \\u0430\\u0434\\u043c\\u0438\\u043d\\u0438\\u0441\\u0442\\u0440\\u0430\\u0442\\u043e\\u0440\\u043e\\u043c", "new_status": "APPROVED", "as_role": null, "description": "\\u0442\\u0435\\u0441\\u0442", "requested_hours": 11.0, "raw_hours_exact": 10.983333333333333, "approved_hours": 11.0}	2026-05-16 13:04:51.199854+00
117	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-16 15:32:27.139499+00
118	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-16 15:32:58.852876+00
119	1	REVIEW_ADMIN	overtime	2	{"approved": true, "comment": "Test 2 2", "new_status": "APPROVED", "as_role": "head", "description": "Test 2", "requested_hours": 3.0, "raw_hours_exact": 3.0, "approved_hours": 3.0}	2026-05-16 15:34:31.854899+00
120	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-20 09:53:12.947897+00
121	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-20 11:43:10.822969+00
122	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-20 11:49:21.081499+00
123	1	CHANGE_PASSWORD	\N	\N	null	2026-05-20 11:50:01.874459+00
124	36	PASSWORD_RESET	\N	\N	null	2026-05-21 06:03:27.463513+00
125	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-21 06:03:28.271062+00
126	36	LOGIN	\N	\N	{"email": "yenjiyevskiy@polymedia.kz"}	2026-05-21 06:03:31.453963+00
127	29	PASSWORD_RESET	\N	\N	null	2026-05-21 06:06:11.553894+00
128	29	LOGIN	\N	\N	{"email": "savchenko@polymedia.kz"}	2026-05-21 06:06:17.774406+00
129	12	PASSWORD_RESET	\N	\N	null	2026-05-21 06:43:47.492704+00
130	12	LOGIN	\N	\N	{"email": "dubinin@polymedia.kz"}	2026-05-21 06:43:56.995429+00
131	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-21 06:44:30.697682+00
132	29	LOGIN	\N	\N	{"email": "savchenko@polymedia.kz"}	2026-05-21 06:46:12.360199+00
133	12	REVIEW_HEAD	overtime	5	{"approved": true, "comment": null, "new_status": "APPROVED", "as_role": null, "description": "\\u274c \\u041e\\u0442\\u043c\\u0435\\u043d\\u0430", "requested_hours": 1.0, "raw_hours_exact": 0.01772551333333333, "approved_hours": 1.0}	2026-05-21 06:46:54.538767+00
134	12	REVIEW_HEAD	overtime	8	{"approved": true, "comment": null, "new_status": "APPROVED", "as_role": null, "description": "\\u0440\\u0430\\u0431\\u043e\\u0442\\u0430\\u043b", "requested_hours": 3.0, "raw_hours_exact": 2.033333333333333, "approved_hours": 2.0}	2026-05-21 06:52:51.203406+00
135	28	PASSWORD_RESET	\N	\N	null	2026-05-21 07:08:04.678166+00
136	28	LOGIN	\N	\N	{"email": "raibekov@polymedia.kz"}	2026-05-21 07:08:15.439948+00
137	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-21 07:39:11.554864+00
138	1	CHANGE_PASSWORD	\N	\N	null	2026-05-21 07:39:36.226675+00
139	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-21 07:41:46.387944+00
140	5	PASSWORD_RESET	\N	\N	null	2026-05-21 08:58:00.596635+00
141	5	LOGIN	\N	\N	{"email": "baskakov@polymedia.kz"}	2026-05-21 08:58:07.631502+00
142	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-21 09:26:06.388899+00
143	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-21 09:26:34.031894+00
144	1	UPDATE_USER	user	35	{"full_name": "\\u0423\\u0440\\u0430\\u0437\\u0431\\u0430\\u043a\\u043e\\u0432 \\u0416\\u0430\\u043d\\u0431\\u043e\\u043b\\u0430\\u0442 \\u0422\\u0443\\u0440\\u0433\\u0430\\u043d\\u043e\\u0432\\u0438\\u0447", "email": "urazbakov@polymedia.kz", "role": "head", "department_id": 6, "company": "Polymedia"}	2026-05-21 09:35:49.578382+00
145	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-21 10:48:29.271766+00
146	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-21 10:48:31.250554+00
147	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-21 13:36:42.639764+00
148	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-21 13:37:24.931958+00
149	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-21 13:49:45.971661+00
150	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-21 14:07:09.07168+00
151	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-21 14:14:09.79848+00
152	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-21 15:08:07.968228+00
153	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-21 15:08:38.751571+00
185	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 08:32:04.856521+00
186	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 08:32:19.5575+00
187	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-23 08:32:30.62532+00
188	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 08:56:42.656492+00
189	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-23 09:00:16.722699+00
190	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-23 09:04:20.264597+00
191	1	UPDATE_USER	user	5	{"full_name": "\\u0411\\u0430\\u0441\\u043a\\u0430\\u043a\\u043e\\u0432 \\u0412\\u0438\\u0442\\u0430\\u043b\\u0438\\u0439", "email": "baskakov@polymedia.kz", "role": "head", "department_id": 6, "company": "Polymedia"}	2026-05-23 09:07:11.944917+00
192	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 09:18:11.737521+00
193	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 09:22:15.126058+00
194	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 09:26:41.661228+00
195	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 09:35:25.560497+00
196	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-23 09:59:15.871121+00
197	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-23 10:00:34.133585+00
198	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 10:02:21.447633+00
199	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 10:04:45.526281+00
200	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 10:06:50.449134+00
201	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 10:09:18.096454+00
202	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-23 10:11:39.530793+00
203	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 10:11:47.924756+00
204	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-23 10:44:35.514312+00
205	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 11:39:26.173639+00
206	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 11:45:40.757931+00
207	1	IMPORT_USER_MS	user	0	{"email": "a.daniyar@profservice.team"}	2026-05-23 11:46:30.853359+00
208	1	CREATE_DEPT	department	9	{"name": "Test departament"}	2026-05-23 11:47:16.384146+00
209	1	UPDATE_DEPT	department	9	{"head_id": 1}	2026-05-23 11:47:56.794334+00
210	1	CREATE_PROJECT	project	5	{"name": "Test project"}	2026-05-23 11:48:23.35832+00
211	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-23 15:46:41.737535+00
212	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 15:47:00.865424+00
213	1	UPDATE_PROJECT	project	2	{"weekly_limit": 51}	2026-05-23 15:47:35.335215+00
214	1	UPDATE_PROJECT	project	2	{"weekly_limit": 52}	2026-05-23 15:47:37.183958+00
215	1	UPDATE_PROJECT	project	2	{"weekly_limit": 53}	2026-05-23 15:47:37.76477+00
216	1	UPDATE_PROJECT	project	2	{"weekly_limit": 54}	2026-05-23 15:47:38.220216+00
217	1	UPDATE_PROJECT	project	2	{"weekly_limit": 55}	2026-05-23 15:47:38.421236+00
218	1	UPDATE_PROJECT	project	2	{"weekly_limit": 56}	2026-05-23 15:47:38.598407+00
219	1	UPDATE_PROJECT	project	2	{"weekly_limit": 57}	2026-05-23 15:47:38.931149+00
220	1	UPDATE_PROJECT	project	2	{"weekly_limit": 58}	2026-05-23 15:47:39.57793+00
221	1	UPDATE_PROJECT	project	2	{"weekly_limit": 6}	2026-05-23 15:47:42.784181+00
222	1	UPDATE_PROJECT	project	2	{"weekly_limit": 60}	2026-05-23 15:47:47.084327+00
223	1	CREATE_PROJECT	project	6	{"name": "Test Project 2"}	2026-05-23 15:49:08.284123+00
224	1	UPDATE_PROJECT	project	6	{"manager_id": 17}	2026-05-23 15:49:19.002098+00
225	1	REVIEW_ADMIN	overtime	11	{"approved": true, "comment": "", "new_status": "APPROVED", "as_role": null, "description": "\\u0422\\u0435\\u0441\\u0442 - \\u041c\\u0430\\u043a\\u0441\\u0430\\u0442 \\u043d\\u0435 \\u043e\\u0441\\u0442\\u0430\\u043d\\u043e\\u0432\\u0438\\u043b \\u0431\\u043e\\u0442\\u0430.", "requested_hours": 1.0, "raw_hours_exact": 0.25, "approved_hours": 6.0}	2026-05-23 15:57:51.537606+00
226	1	REVIEW_ADMIN	overtime	3	{"approved": true, "comment": null, "new_status": "APPROVED", "as_role": null, "description": "\\u0418 \\u0432\\u044b\\u0445\\u043e\\u0434\\u043d\\u044b\\u0435 \\u0437\\u0430\\u043d\\u0438\\u043c\\u0430\\u043b\\u0438\\u0441\\u044c \\u043f\\u0435\\u0440\\u0435\\u0434\\u0435\\u043b\\u043a\\u043e\\u0439 \\u0441\\u0435\\u0440\\u0432\\u0438\\u0441\\u043d\\u043e\\u0439 \\u043a\\u043e\\u043c\\u043d\\u0430\\u0442.", "requested_hours": 1.0, "raw_hours_exact": 0.030611955000000003, "approved_hours": 2.0}	2026-05-23 15:59:37.21824+00
227	1	REVIEW_ADMIN	overtime	3	{"approved": true, "comment": null, "new_status": "APPROVED", "as_role": null, "description": "\\u0418 \\u0432\\u044b\\u0445\\u043e\\u0434\\u043d\\u044b\\u0435 \\u0437\\u0430\\u043d\\u0438\\u043c\\u0430\\u043b\\u0438\\u0441\\u044c \\u043f\\u0435\\u0440\\u0435\\u0434\\u0435\\u043b\\u043a\\u043e\\u0439 \\u0441\\u0435\\u0440\\u0432\\u0438\\u0441\\u043d\\u043e\\u0439 \\u043a\\u043e\\u043c\\u043d\\u0430\\u0442.", "requested_hours": 1.0, "raw_hours_exact": 0.030611955000000003, "approved_hours": 2.0}	2026-05-23 15:59:43.092994+00
228	1	UPDATE_PROJECT	project	2	{"weekly_limit": 61}	2026-05-23 16:01:30.652345+00
229	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 16:19:54.907064+00
230	1	REVIEW_ADMIN	overtime	44	{"approved": true, "comment": null, "new_status": "APPROVED", "as_role": null, "description": "Test work", "requested_hours": 12.0, "raw_hours_exact": 12.0, "approved_hours": 11.0}	2026-05-23 16:24:25.617435+00
231	1	UPDATE_PROJECT	project	4	{"weekly_limit": 52}	2026-05-23 16:30:50.882877+00
232	1	UPDATE_PROJECT	project	4	{"manager_id": 11}	2026-05-23 16:30:52.55077+00
233	1	UPDATE_PROJECT	project	4	{"manager_id": 25}	2026-05-23 16:30:56.812237+00
234	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 17:20:44.433197+00
235	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-23 17:21:20.0607+00
236	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 17:54:31.85873+00
237	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 17:56:28.839907+00
238	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-23 18:19:33.485406+00
239	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 18:32:54.609883+00
240	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-23 19:03:10.006109+00
241	1	UPDATE_PROJECT	project	2	{"weekly_limit": 58}	2026-05-23 19:03:25.282186+00
242	1	UPDATE_PROJECT	project	2	{"manager_id": 17}	2026-05-23 19:03:29.777268+00
243	1	UPDATE_PROJECT	project	2	{"manager_id": 16}	2026-05-23 19:03:32.741281+00
249	6	LOGIN	\N	\N	{"email": "chmil@polymedia.kz"}	2026-05-25 06:45:45.757509+00
250	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-25 06:46:00.510774+00
251	1	LOGIN	\N	\N	{"email": "admin@example.com"}	2026-05-25 07:29:09.007836+00
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: overtime_user
--

COPY public.departments (id, name, head_id) FROM stdin;
2	МИО-Астана	12
3	ОПР	6
6	Технический отдел	5
1	ГИП	27
4	ОПД	32
5	МТО - Алматы	35
8	Коммерческий отдел	7
7	Отдел продаж	2
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: overtime_user
--

COPY public.notifications (id, user_id, title, message, is_read, created_at) FROM stdin;
1	25	Новая заявка	Новая заявка #1\nОт: Чмиль Никита Павлович\nПроект: Департамент полиции Атырауской области МВД РК ГУ_ЦОУ\nЧасы: 11.0\nТребуется решение	f	2026-05-16 13:03:38.603369+00
6	16	Новая заявка	Новая заявка #2\nОт: Чмиль Никита Павлович\nПроект: ООО "Нет Солюшенс"_СЦ Душанбе\nЧасы: 3.0\nТребуется решение	f	2026-05-16 15:34:11.854821+00
9	27	Новая заявка	Новая заявка #4\nОт: Енджиевский Юрий Игоревич\nПроект: СК Формация\nЧасы: 10.0\nТребуется решение	f	2026-05-21 06:04:54.026863+00
10	16	Новая заявка	Новая заявка #6\nОт: Енджиевский Юрий Игоревич\nПроект: ООО "Нет Солюшенс"_СЦ Душанбе\nЧасы: 50.0\nТребуется решение	f	2026-05-21 06:16:01.946011+00
11	27	Новая заявка	Новая заявка #6\nОт: Енджиевский Юрий Игоревич\nПроект: ООО "Нет Солюшенс"_СЦ Душанбе\nЧасы: 50.0\nТребуется решение	f	2026-05-21 06:16:01.947767+00
12	16	Новая заявка	Новая заявка #7\nОт: Енджиевский Юрий Игоревич\nПроект: ООО "Нет Солюшенс"_СЦ Душанбе\nЧасы: 9.0\nТребуется решение	f	2026-05-21 06:16:54.358479+00
13	27	Новая заявка	Новая заявка #7\nОт: Енджиевский Юрий Игоревич\nПроект: ООО "Нет Солюшенс"_СЦ Душанбе\nЧасы: 9.0\nТребуется решение	f	2026-05-21 06:16:54.360003+00
14	29	✅ Одобрена	Обновление заявки #5\nСтатус: ✅ Одобрена\nПроект: Департамент полиции Атырауской области МВД РК ГУ_ЦОУ\nВремя: 21.05 06:10 — 06:11	f	2026-05-21 06:46:54.545808+00
15	25	Новая заявка	Новая заявка #8\nОт: Савченко Виктор Геннадьевич\nПроект: Департамент полиции Атырауской области МВД РК ГУ_ЦОУ\nЧасы: 3.0\nТребуется решение	f	2026-05-21 06:47:01.335058+00
16	12	Новая заявка	Новая заявка #8\nОт: Савченко Виктор Геннадьевич\nПроект: Департамент полиции Атырауской области МВД РК ГУ_ЦОУ\nЧасы: 3.0\nТребуется решение	f	2026-05-21 06:47:01.336864+00
17	29	✅ Одобрена	Обновление заявки #8\nСтатус: ✅ Одобрена\nПроект: Департамент полиции Атырауской области МВД РК ГУ_ЦОУ\nВремя: 20.05 11:46 — 13:48	f	2026-05-21 06:52:51.209355+00
18	12	Новая заявка	Новая заявка #9\nОт: Савченко Виктор Геннадьевич\nПроект: СК Формация\nЧасы: 4.0\nТребуется решение	f	2026-05-21 06:56:04.468488+00
19	28	✅ Одобрена	Обновление заявки #11\nСтатус: ✅ Одобрена\nПроект: СК Формация\nВремя: 21.05 01:45 — 02:00	f	2026-05-23 15:57:51.543091+00
22	16	Новая заявка	Новая заявка #44\nОт: System Administrator\nПроект: ООО "Нет Солюшенс"_СЦ Душанбе\nЧасы: 12.0\nТребуется решение	f	2026-05-23 16:20:57.573407+00
23	5	Новая заявка	Новая заявка #44\nОт: System Administrator\nПроект: ООО "Нет Солюшенс"_СЦ Душанбе\nЧасы: 12.0\nТребуется решение	f	2026-05-23 16:20:57.576795+00
2	6	Новая заявка	Новая заявка #1\nОт: Чмиль Никита Павлович\nПроект: Департамент полиции Атырауской области МВД РК ГУ_ЦОУ\nЧасы: 11.0\nТребуется решение	t	2026-05-16 13:03:38.607096+00
3	6	✅ Одобрена	Обновление заявки #1\nСтатус: ✅ Одобрена\nПроект: Департамент полиции Атырауской области МВД РК ГУ_ЦОУ\nВремя: 09.05 08:05 — 19:04\nКомментарий: Одобрено администратором	t	2026-05-16 13:04:47.29004+00
4	6	✅ Одобрена	Обновление заявки #1\nСтатус: ✅ Одобрена\nПроект: Департамент полиции Атырауской области МВД РК ГУ_ЦОУ\nВремя: 09.05 08:05 — 19:04\nКомментарий: Одобрено администратором	t	2026-05-16 13:04:49.49453+00
7	6	Новая заявка	Новая заявка #2\nОт: Чмиль Никита Павлович\nПроект: ООО "Нет Солюшенс"_СЦ Душанбе\nЧасы: 3.0\nТребуется решение	t	2026-05-16 15:34:11.858488+00
20	1	✅ Одобрена	Обновление заявки #3\nСтатус: ✅ Одобрена\nПроект: ООО "Нет Солюшенс"_СЦ Душанбе\nВремя: 20.05 11:59 — 12:01	t	2026-05-23 15:59:37.224563+00
21	1	✅ Одобрена	Обновление заявки #3\nСтатус: ✅ Одобрена\nПроект: ООО "Нет Солюшенс"_СЦ Душанбе\nВремя: 20.05 11:59 — 12:01	t	2026-05-23 15:59:43.097671+00
24	1	✅ Одобрена	Обновление заявки #44\nСтатус: ✅ Одобрена\nПроект: ООО "Нет Солюшенс"_СЦ Душанбе\nВремя: 21.05 09:20 — 21:20	t	2026-05-23 16:24:25.62622+00
5	6	✅ Одобрена	Обновление заявки #1\nСтатус: ✅ Одобрена\nПроект: Департамент полиции Атырауской области МВД РК ГУ_ЦОУ\nВремя: 09.05 08:05 — 19:04\nКомментарий: Одобрено администратором	t	2026-05-16 13:04:51.204588+00
8	6	✅ Одобрена	Обновление заявки #2\nСтатус: ✅ Одобрена\nПроект: ООО "Нет Солюшенс"_СЦ Душанбе\nВремя: 15.05 20:00 — 23:00\nКомментарий: Test 2 2	t	2026-05-16 15:34:31.862294+00
\.


--
-- Data for Name: overtimes; Type: TABLE DATA; Schema: public; Owner: overtime_user
--

COPY public.overtimes (id, user_id, project_id, start_lat, start_lng, end_lat, end_lng, start_time, end_time, description, status, created_at, manager_approved, head_approved, manager_comment, head_comment, location_name, voice_url, voice_summary, approved_hours) FROM stdin;
1	6	4	\N	\N	\N	\N	2026-05-09 08:05:00	2026-05-09 19:04:00	тест	APPROVED	2026-05-16 13:03:38.589081+00	t	t	Одобрено администратором	Одобрено администратором		\N	\N	11
2	6	2	\N	\N	\N	\N	2026-05-15 20:00:00	2026-05-15 23:00:00	Test 2	APPROVED	2026-05-16 15:34:11.844481+00	\N	t	\N	Test 2 2		\N	\N	3
4	36	3	\N	\N	\N	\N	2026-05-20 07:04:00	2026-05-20 16:14:00	прост	PENDING	2026-05-21 06:04:54.014311+00	\N	\N	\N	\N	Шарль де гоголя 3	\N	\N	\N
6	36	2	\N	\N	\N	\N	2026-05-07 11:15:00	2026-05-09 13:15:00	123	PENDING	2026-05-21 06:16:01.939662+00	\N	\N	\N	\N	123	\N	\N	\N
7	36	2	\N	\N	\N	\N	2026-05-14 11:16:00	2026-05-14 19:37:00	123	PENDING	2026-05-21 06:16:54.352028+00	\N	\N	\N	\N	123	\N	\N	\N
5	29	4	51.142178	71.44914	51.142178	71.44914	2026-05-21 06:10:13.869341	2026-05-21 06:11:17.681189	❌ Отмена	APPROVED	2026-05-21 06:10:13.869751+00	\N	t	\N	\N	\N	\N	\N	1
8	29	4	\N	\N	\N	\N	2026-05-20 11:46:00	2026-05-20 13:48:00	работал	APPROVED	2026-05-21 06:47:01.329218+00	\N	t	\N	\N	тут	\N	\N	2
9	29	3	\N	\N	\N	\N	2026-05-19 11:52:00	2026-05-19 15:02:00	как обычно работал	PENDING	2026-05-21 06:56:04.459849+00	\N	\N	\N	\N	в офисе был	\N	\N	\N
10	28	3	51.142171	71.449103	51.142163	71.449189	2026-05-21 11:37:08.442064	2026-05-21 11:44:52.111317	Замена кабелей.	PENDING	2026-05-21 11:37:08.443066+00	\N	\N	\N	\N	\N	uploads/voice/10_28.ogg	\N	\N
11	28	3	51.142163	71.449189	\N	\N	2026-05-21 01:45:00	2026-05-21 02:00:00	Тест - Максат не остановил бота.	APPROVED	2026-05-21 11:45:12.01101+00	t	t			КНБ Авиа	\N	\N	6
3	1	2	51.142178	71.44914	51.142178	71.44914	2026-05-20 11:59:58.054234	2026-05-20 12:01:48.257272	И выходные занимались переделкой сервисной комнат.	APPROVED	2026-05-20 11:59:58.055085+00	t	t	\N	\N	\N	uploads/voice/3_1.ogg	\N	2
44	1	2	\N	\N	\N	\N	2026-05-21 09:20:00	2026-05-21 21:20:00	Test work	APPROVED	2026-05-23 16:20:57.560486+00	t	t	\N	\N		\N	\N	11
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: overtime_user
--

COPY public.projects (id, name, manager_id, weekly_limit, code, is_active) FROM stdin;
3	СК Формация	\N	50	\N	t
6	Test Project 2	17	50	2027-00001	t
4	Департамент полиции Атырауской области МВД РК ГУ_ЦОУ	25	52	\N	t
2	ООО "Нет Солюшенс"_СЦ Душанбе	16	58	\N	t
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: overtime_user
--

COPY public.refresh_tokens (id, user_id, token, expires_at, created_at, revoked) FROM stdin;
1	6	zufgz1s3wPS4GhUrgNkJXDRTI0aQdBOqtC0BW0fOy4YJntTPmxQM5MaRkVxeAXSv_47UMlBWCBYw5RJWh-qS3w	2026-06-01 06:45:45.759175+00	2026-05-25 06:45:45.759946+00	t
2	1	cBJxk_l67EvKbGhnNWnIsdTjBlgq8Xz5yd-771D3qPnhAqmeAM6DwSbPAHF401vJi6wWv22-eCkYsOmtfd9kbQ	2026-06-01 06:46:00.512197+00	2026-05-25 06:46:00.512427+00	t
4	1	wrq5Y6ds7lIGHndy3t9hlgemTbZQ0I3sFXkzUXC4OBipOCe4BONoBl2fiffn6yHsk1WmBC2UjAdt7jkdMRxPWg	2026-06-01 07:16:03.294843+00	2026-05-25 07:16:03.29613+00	t
3	6	2JhDqe4XidZQMOpTY1-CkusrsQ86jm7fN314r534bVrhB2rFqOzbubkQgQw5OcP5nOAvcJiA4vaynVSI5aiqzQ	2026-06-01 07:16:03.273435+00	2026-05-25 07:16:03.275651+00	t
5	1	nI02MowF81P7qlmGEtTmD-sKXjBl-4N6sNiH7qKrrSKNvy2VUwg3aQiINOSlo3ZIdTntjDHOrAR2dxYCW3TWYQ	2026-06-01 07:29:09.00919+00	2026-05-25 07:29:09.009363+00	t
6	6	0VsF9gx6WmHfqOJ4Xvc-_tQHsNU-Nwd7ylIAKrja-hY-SZdjMEyFAXe_K1cqRicq7E0h18pYWscNCooFhb2K9g	2026-06-01 07:46:03.270917+00	2026-05-25 07:46:03.271479+00	t
7	1	Rlk94X7hI_q8hRHkK19n08KdRd-nplFT38ERBTVsDjTbwk0l39ngpDfipEui-9YUUDb28rnPRT9iqN57Devvhw	2026-06-01 07:59:19.686928+00	2026-05-25 07:59:19.689294+00	t
8	6	cN8ADcRcD_V_zfu8WA-u3gomTS1LqG4GEAOAEmcivz_gGSl5Dm6shMrkd49zTw2TYN_LuTsVTq8EAgn4ckGE8Q	2026-06-01 08:16:07.070874+00	2026-05-25 08:16:07.073442+00	t
9	1	k9_ByDZ8h_PaUb4WumMdZKRnjO0cq-zRSV5cO7hyG5ioCBD_p4Mgjkea46GB4JsMLwBsDVB0p90d83zVnZkUmg	2026-06-01 08:29:29.624876+00	2026-05-25 08:29:29.626253+00	t
10	6	rMp_MnfMYNL0KbsKfnyh6Z41_3xoKQut9jMKx8I66XqsBSOUO-Wl7dou2-xrgXFd5E3rFbchVyQHGbPXVJkLtQ	2026-06-01 08:46:34.070546+00	2026-05-25 08:46:34.071463+00	t
11	1	SV9m-hF7BVaHKpKeT4V7BkFnwn5R8X4if01M1kQAeXZqoRiwr9nt6AiPyhq2uLu5J2mJdwudExqovyvBUgLdXw	2026-06-01 08:59:29.623949+00	2026-05-25 08:59:29.624679+00	t
12	6	7rscbo_7Haxf4O9bmunj3moEJwtULOii5xlHmrpx3Q0xNuLcdWrrdDJ9JpIQ53zdZvyxSyfHqyafhVQ3ISOOcA	2026-06-01 09:16:34.067678+00	2026-05-25 09:16:34.068475+00	t
13	1	TG_EQiOCX4qAmOrsqj5Q25kMuSfBgklDHD1zujAndpQCD7R-6RcMayvXZcbAdR0K3Y7BdrWAbsNjPjYTJFE8Qw	2026-06-01 09:29:29.624589+00	2026-05-25 09:29:29.625269+00	t
14	6	UXAAMsqlRV2Ck3j9mg0G581CS3QmuSseJ6p_vNy6j3fe5l064HMftt6XkqjjtXlUof_iYC6M_HYIJZm3mIGpCg	2026-06-01 09:46:34.073774+00	2026-05-25 09:46:34.074781+00	t
15	1	p05cUafU8RlAumK6iIin1xBQH6uY8oYhPjSE2rnx2k_vZO2srB3bJmgBI8RSavP9vv4yWjMu-gvvxNdUJZwDIA	2026-06-01 09:59:29.623645+00	2026-05-25 09:59:29.624258+00	t
16	6	K-8FZ_J8eY1h7njgILPsz7k3erZN-Sa_q_5Eg7SKKDoJRUsVbCQ7h2NVVefwDQ3j4kQ9nKc_EevKH6ZjwOxiWA	2026-06-01 10:16:34.083495+00	2026-05-25 10:16:34.084382+00	t
17	1	cXJTrCZdKqxzyz13Slr8ksXt19BjxsubN__b_NjiQxpuh0FvxsQoTuqgheXqKZy-vygs_uAPfSC-3BMwlZdROA	2026-06-01 10:29:29.62441+00	2026-05-25 10:29:29.62516+00	t
18	6	V82QgZ6FseHL0u1LCrcK5GdydTgj3kusBKXwscu1CZ1E9JPD6QrLMwMxomFHyl9KjcP5nQL34-_YnCPZghqMLQ	2026-06-01 10:46:34.076055+00	2026-05-25 10:46:34.076886+00	t
19	1	jB7SWmhxxMV1oqaLQxf1bP-QvzrRnr1moHR_jDZ8oWifQBZbzHjtJj9GnCzgtGHaplEBKWwVw_YLZvf-gz5HnA	2026-06-01 10:59:29.623794+00	2026-05-25 10:59:29.624516+00	t
20	6	pJngpGgfmpXx_b28m8U7OOA8iydGYlbnT_xlL4V3F9ABlEG1wagbeZWNqSW_B2jKO9ztHJ4rkYsn2r43_1ZVTA	2026-06-01 11:16:34.077205+00	2026-05-25 11:16:34.077903+00	t
21	1	cPKworpv2DWKUnYKwalwuPnkc0UMSFSyzrMykmd6YtR4Mi7yBmrSteh9K9d9OX6jDK8WgKwOTAWFfs6NSC_isQ	2026-06-01 11:29:29.624341+00	2026-05-25 11:29:29.625077+00	t
22	6	NkF4TcEP99mZoDrrPJAMyYcVDtvr_YQdzxEabXd-4qfbe7qVbtCyx9NcxLLgfb2F2GdDUKXo1PWPMiFNX_R5XQ	2026-06-01 11:46:46.067623+00	2026-05-25 11:46:46.068244+00	t
23	1	7iUOyT0lkNvFbaVMjAsrhNBaIoTOVMotnYdyHsGzDJOnycc6lEPZLKj12pmpPfLLgyZxwvjSVYV2cSb84czDCg	2026-06-01 11:59:29.623938+00	2026-05-25 11:59:29.624571+00	t
24	6	qYKgu2bb1XQtE8tf3DOaXlnST7RUqS-zySZ4zQHKkC8GvQJgAabsaWM44vigEFThpGoMRVBXTK_-1NlAjz7B8A	2026-06-01 12:17:34.078481+00	2026-05-25 12:17:34.07939+00	t
25	1	sh_5KKvuNbMO0S2HhueyW3ifZ3sUwis6M72eAYxwMbNRAEK860fqo-P7dRQBV-gnza3O-hk7zepOVWF2I8Jubg	2026-06-01 12:29:29.623652+00	2026-05-25 12:29:29.624411+00	t
26	6	N5fcweEaAkEWVkZlK37SkQKnpnqY0h-VmkUYpTQOdj-744lnH1Qs67L9xmHUei00aYUKYPr5eMWZRJF3Za8udw	2026-06-01 12:47:34.092272+00	2026-05-25 12:47:34.093222+00	t
28	6	QeGDrvcxKQ8qiSktiqhe-F1DBVe5Xkk-PHSesYmQXszz58J5Bss172060oL7AO4Ll8W2NmwQgD_Kq0r14JWzpw	2026-06-01 13:17:34.070978+00	2026-05-25 13:17:34.07221+00	f
27	1	0orBeXFVb2H9jBfpRavk_PY2Wx0-X_NI_yjkX31gtSI6WzJuKJZK6DNp3d1QXHfgs5FWXs3l0qYsJKdTkCLm4g	2026-06-01 12:59:29.628198+00	2026-05-25 12:59:29.630552+00	t
29	1	0Jow8iPDhJPOG_EZpr3pY9aP9pvm-T_IadV7XUyYceFtcoBUDOHebHqIJwUvzAajnn2Qq_pQkjhgkROKvVRuQg	2026-06-01 13:29:29.623565+00	2026-05-25 13:29:29.624346+00	f
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: overtime_user
--

COPY public.system_settings (key, value) FROM stdin;
\.


--
-- Data for Name: user_otps; Type: TABLE DATA; Schema: public; Owner: overtime_user
--

COPY public.user_otps (id, user_id, code, type, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: overtime_user
--

COPY public.users (id, full_name, email, hashed_password, is_active, role, created_at, updated_at, department_id, telegram_chat_id, notification_level, must_change_password, is_2fa_enabled, company) FROM stdin;
35	Уразбаков Жанболат Турганович	urazbakov@polymedia.kz	$2b$12$GdwCiU09PxuD5oBd2D2CNu4eJH8R0wDW2EYMjKanDXHhc1YwQoBjG	t	head	2026-05-16 10:43:21.480983+00	2026-05-21 09:35:49.575162+00	6	\N	2	t	f	Polymedia
3	Nikita Chmil (Admin)	admin@plmkz.onmicrosoft.com	$2b$12$w5P6wCZD05yNAgI/7Zc1O.eN2p7xDzM3OyUxYagJSuvo5Anf8iTja	t	admin	2026-05-16 10:43:15.41404+00	2026-05-16 12:11:12.299715+00	6	\N	2	t	f	Polymedia
2	Ашимов Асхат Халимулиевич	a.ashimov@polymedia.kz	$2b$12$CyZwWKnNnztdxXn/CyMYDu1uyN1Z4PNjO1Q/B6lBHJvMPb2Utc9HC	t	head	2026-05-16 10:43:15.224981+00	2026-05-16 12:25:54.934812+00	7	\N	2	t	f	Polymedia
4	Балтабекова Мерей Кабиболлаевна	baltabekova@polymedia.kz	$2b$12$4BStANPUScVITpo1JoenT.bGsSBVa5XLDhkACo5jCQwARvZJLXGhW	t	employee	2026-05-16 10:43:15.608736+00	2026-05-16 12:26:03.085222+00	8	\N	2	t	f	Polymedia
36	Енджиевский Юрий Игоревич	yenjiyevskiy@polymedia.kz	$2b$12$PofSDWeGfAb9WP9PNEvYte2hosSmC2RAm/m7mHesF/QDL1QKtjENG	t	employee	2026-05-16 10:43:21.670064+00	2026-05-21 06:03:27.459368+00	1	\N	2	f	f	Polymedia
10	Станислав Владимирович Долженко	dolzhenko@polymedia.kz	$2b$12$BHiagxwh4je/uJxHfRRtfeO/EPC19uoRbIGd5s9S5Y6TIw6e2wsM2	t	employee	2026-05-16 10:43:16.738712+00	2026-05-16 12:27:56.514042+00	6	\N	2	t	f	Polymedia
8	Дмитриев Артём	dmitriyev@polymedia.kz	$2b$12$lvEW69qN8h6GdBzmAo0YfeMDNHk6su.SRBKWduqMYew9VjjBMRlLC	t	employee	2026-05-16 10:43:16.357053+00	2026-05-16 12:26:42.075839+00	5	\N	2	t	f	Polymedia
9	Дощанов Руслан Аскарович	dochshanov@polymedia.kz	$2b$12$hjYAK11ErvP7Z5PU9prb3OBiQ0OZxjifc1zp4H820q28hPw8jywBS	t	employee	2026-05-16 10:43:16.54884+00	2026-05-16 12:26:49.346377+00	3	\N	2	t	f	Polymedia
38	Тимур Жанпейсов	zhanpeisov@polymedia.kz	$2b$12$lvhHOhFUeeAmKo41UTBjUeD7cGWuvP9BuUIXk0ooksi08RD61KclG	t	employee	2026-05-16 10:43:22.048519+00	2026-05-16 12:27:06.496431+00	2	\N	2	t	f	Polymedia
7	Хамзин Даурен Семигазыевич	d.khamzin@polymedia.kz	$2b$12$RqQyG6JMyxFPMcx/ayyAaOdxPxcTlRoLlYbdHO3HXHphFzDTQMo5S	t	head	2026-05-16 10:43:16.16733+00	2026-05-16 12:27:16.108202+00	8	\N	2	t	f	Polymedia
11	Владимир Дрылев	drylev@polymedia.kz	$2b$12$90t4gPo26RpfZiRBFqpj/e1oDtuesaidVRKXVOYj0GmlznUI20QhC	t	manager	2026-05-16 10:43:16.931392+00	2026-05-16 12:28:21.016276+00	7	\N	2	t	f	Polymedia
12	Дубинин Владимир Иванович	dubinin@polymedia.kz	$2b$12$dRjj4VUaPZLGSVtQ2RpMQebZq0ZpHfJlRJeNFQ7Aox0GdhlIq0/Qi	t	head	2026-05-16 10:43:17.120124+00	2026-05-21 06:54:42.42993+00	2	498805227	2	f	f	Polymedia
13	Аружан Тойболовна Ибрагимова	ibragimova@polymedia.kz	$2b$12$jZYOmvzvpsMJh7gd4OLtPujMmNeYqnMIRyVplu9JIy12v2btr8EFe	t	employee	2026-05-16 10:43:17.307863+00	2026-05-16 12:28:42.095622+00	8	\N	2	t	f	Polymedia
14	Ибраев Айдар Ерболович	ibrayev@polymedia.kz	$2b$12$Y9is.9aTlWOUFsIHH8If/u/IGXFcbcoVqJg5govDJ3T9kqSkASnI2	t	employee	2026-05-16 10:43:17.500502+00	2026-05-16 12:28:52.838077+00	7	\N	2	t	f	Polymedia
15	Игимбеков Нурлан Булатович	igembekov@polymedia.kz	$2b$12$/Vi27U38Tl64vZbp.DISzuXG/ytSSoEqbImiHOKiHQ4NssclcW5au	t	employee	2026-05-16 10:43:17.693056+00	2026-05-16 12:29:01.502732+00	5	\N	2	t	f	Polymedia
16	Кабдешов Замир	kabdeshov@polymedia.kz	$2b$12$BLw7oTxQBK9EiUz0IlCO7uOAfIGU.6fMPtA09UMy5yf7vsUw9nrEC	t	manager	2026-05-16 10:43:17.887852+00	2026-05-16 12:29:39.688856+00	7	\N	2	t	f	Polymedia
37	Заболотских Вячеслав	zabolotskikh@polymedia.kz	$2b$12$T4xjDpEdFrQincqSzVW1Ke51tb2HtDmAfd0TGXtkoHgEOWZwexu1S	t	employee	2026-05-16 10:43:21.860736+00	2026-05-16 12:29:50.738943+00	1	\N	2	t	f	Polymedia
1	System Administrator	admin@example.com	$2b$12$1rx8zsnCl3FfLLb2AYbDZunKPAC/UQ8b67fTDgsIiI1hPW26kqSRu	t	admin	2026-05-15 12:51:38.479736+00	2026-05-21 07:39:36.224452+00	6	349027005	2	f	f	Polymedia
17	Жанболат Казкенулы	kazkenuly@polymedia.kz	$2b$12$2WmFWJ0cmJsbBxqUQo/Bb.8NYqWl0W6duOmN43wSqvLW02ihPUxlS	t	manager	2026-05-16 10:43:18.076098+00	2026-05-16 12:30:11.826538+00	7	\N	2	t	f	Polymedia
21	Роман Магай	magay@polymedia.kz	$2b$12$V6MIiBewL.t.CIRrV/MkTuuG6/4jeSGO6odB4hcgJBOebEkXtpA5q	t	employee	2026-05-16 10:43:18.842043+00	2026-05-16 12:30:56.542556+00	1	\N	2	t	f	Polymedia
18	Кристина Хорольская	khorolskaya@polymedia.kz	$2b$12$w/nElgkpIzI8XRy8tyYQ6.dRHhlM2dXzWgqfA2w04O9WwaKT6g3F.	t	employee	2026-05-16 10:43:18.270559+00	2026-05-16 12:31:05.841811+00	8	\N	2	t	f	Polymedia
19	Кулахметова Елена Анатольевна	kulakhmetova@polymedia.kz	$2b$12$2OsQgadNDVmIqWR664u2..4VkP30rOLkPW1XHEbIty/K0CUuFFKq2	t	employee	2026-05-16 10:43:18.466015+00	2026-05-16 12:31:12.334719+00	8	\N	2	t	f	Polymedia
22	Дулат Мақаш	makash@polymedia.kz	$2b$12$n5kNmbiHioRvO9H9J5X4RuYkDLCaHIAaOLHCdVPtJEWkAJF9H7z/i	t	employee	2026-05-16 10:43:19.027983+00	2026-05-16 12:31:23.364606+00	7	\N	2	t	f	Polymedia
23	Мухажан Хамитхан	mukhazhan@polymedia.kz	$2b$12$pbxUwGbgLkLxd7aKv1wJbu4mOlxsYHFs8mJ/bjgmMSlbtWzg4t7/a	t	employee	2026-05-16 10:43:19.213609+00	2026-05-16 12:31:32.558588+00	4	\N	2	t	f	Polymedia
25	Набиев Магжан Болатбекулы	nabiev@polymedia.kz	$2b$12$evE151NZUFyrwnssqllNH.aGon/O49lXs5oiByaZSHrce1Mx/YMKO	t	manager	2026-05-16 10:43:19.591047+00	2026-05-16 12:31:42.605664+00	7	\N	2	t	f	Polymedia
24	Нуралы Абдрахман	n.abdrakhman@polymedia.kz	$2b$12$W3ksNJo9erAeL0P/hRmDluADnOGiQ4cwjVfqX0E2LDFH407DtPmIC	t	manager	2026-05-16 10:43:19.399351+00	2026-05-16 12:31:56.160727+00	7	\N	2	t	f	Polymedia
26	Пронченко Сергей Викторович	pronchenko@polymedia.kz	$2b$12$W9zima7xEUvKtXHDi8eQ7.k0fytdl1HEvU4KB0Cc7r9PJU4O.fruK	t	manager	2026-05-16 10:43:19.781294+00	2026-05-16 12:32:09.697012+00	7	\N	2	t	f	Polymedia
28	Райбеков Максат	raibekov@polymedia.kz	$2b$12$oiEnt7/C3bThGCVkyfbnneAvEwwrM0eE1RXW1fuQYYw9mp3UQSady	t	employee	2026-05-16 10:43:20.162296+00	2026-05-21 07:09:37.04147+00	2	1015445026	2	f	f	Polymedia
27	Просвирин Юрий Петрович	prosvirin@polymedia.kz	$2b$12$EeoFeUAC6qCVYlmfgDzP8OijfXrfVf9NyK3G19EHgD5koC7TyWeHe	t	head	2026-05-16 10:43:19.97343+00	2026-05-16 12:32:30.084907+00	1	\N	2	t	f	Polymedia
29	Савченко Виктор Геннадьевич	savchenko@polymedia.kz	$2b$12$rMp3229egtpzosD8JZxyLOejztAa4QScaD3FmvF993C44q.HTfECW	t	employee	2026-05-16 10:43:20.347724+00	2026-05-21 06:08:50.285417+00	2	1205333492	2	f	f	Polymedia
30	Шадаев Бауржан Муратбекович	shadayev@polymedia.kz	$2b$12$gl0iFaJSPHpVjwFKlq2PkOuFOcWoGeFQKkG2a3Dt1i9whbeIbEafi	t	manager	2026-05-16 10:43:20.53451+00	2026-05-16 12:32:50.112751+00	7	\N	2	t	f	Polymedia
5	Баскаков Виталий	baskakov@polymedia.kz	$2b$12$ee4ubCnazZJeJ.0gm0eAX.ZGcN2Dn63sUXhgGQxxa4rukREgKWu4e	t	head	2026-05-16 10:43:15.795109+00	2026-05-23 09:07:11.93919+00	6	\N	2	f	f	Polymedia
34	Терегулова Регина	Teregulova@polymedia.kz	$2b$12$m8pVX6XbtOQ9dzRHPiyIzOqVTJHJ8Ow0D2qT7y7tSZxYoR2RWdeV2	t	employee	2026-05-16 10:43:21.296356+00	2026-05-16 12:33:08.87151+00	4	\N	2	t	f	Polymedia
33	Скобликов Вячеслав Сергеевич	skoblikov@polymedia.kz	$2b$12$fte0BNyPrLLJ8BX35Ybl1eze0mC3QP8gONTuBrLeawIK4NZQu73F6	t	employee	2026-05-16 10:43:21.110257+00	2026-05-16 12:33:17.03523+00	1	\N	2	t	f	Polymedia
31	Швецов Егор Сергеевич	shvetsov@polymedia.kz	$2b$12$zh41z2dnOvlDTnldXcSlxOlylqJhi7RbmObNWvWa1CrJ8f0prq7oK	t	employee	2026-05-16 10:43:20.733686+00	2026-05-16 12:33:29.913082+00	1	\N	2	t	f	Polymedia
32	Сидоренко Сергей Александрович	sidorenko@polymedia.kz	$2b$12$aYJtp8aa/gS0F1H8Ktsq/.n.fE14JzCShi/kDlXCK4RzGusn2GZp6	t	head	2026-05-16 10:43:20.925117+00	2026-05-16 12:33:41.519207+00	4	\N	2	t	f	Polymedia
6	Чмиль Никита Павлович	chmil@polymedia.kz	$2b$12$3aR7Jf9ItzoBYYNcT4iVL./91o4RYanyTwK8If0.lsFb2udcvTpMy	t	head	2026-05-16 10:43:15.981007+00	2026-05-20 11:43:21.32589+00	3	349027005	2	f	f	Polymedia
20	Анастасия Александровна Литвинова	litvinova@polymedia.kz	$2b$12$iaVotO6JNinL7UaxvlqBZuwRgXDHULI.KXBKPCw9tYgT.Snxa31ZW	t	employee	2026-05-16 10:43:18.655784+00	2026-05-16 12:30:46.097003+00	6	\N	2	t	f	Polymedia
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: overtime_user
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 251, true);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: overtime_user
--

SELECT pg_catalog.setval('public.departments_id_seq', 9, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: overtime_user
--

SELECT pg_catalog.setval('public.notifications_id_seq', 24, true);


--
-- Name: overtimes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: overtime_user
--

SELECT pg_catalog.setval('public.overtimes_id_seq', 44, true);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: overtime_user
--

SELECT pg_catalog.setval('public.projects_id_seq', 6, true);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: overtime_user
--

SELECT pg_catalog.setval('public.refresh_tokens_id_seq', 29, true);


--
-- Name: user_otps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: overtime_user
--

SELECT pg_catalog.setval('public.user_otps_id_seq', 6, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: overtime_user
--

SELECT pg_catalog.setval('public.users_id_seq', 39, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: overtimes overtimes_pkey; Type: CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.overtimes
    ADD CONSTRAINT overtimes_pkey PRIMARY KEY (id);


--
-- Name: projects projects_code_key; Type: CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_code_key UNIQUE (code);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: user_otps user_otps_pkey; Type: CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.user_otps
    ADD CONSTRAINT user_otps_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_refresh_tokens_token; Type: INDEX; Schema: public; Owner: overtime_user
--

CREATE UNIQUE INDEX ix_refresh_tokens_token ON public.refresh_tokens USING btree (token);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: departments departments_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.users(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: overtimes overtimes_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.overtimes
    ADD CONSTRAINT overtimes_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: overtimes overtimes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.overtimes
    ADD CONSTRAINT overtimes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: projects projects_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id);


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_otps user_otps_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.user_otps
    ADD CONSTRAINT user_otps_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: overtime_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- PostgreSQL database dump complete
--

\unrestrict lbg3d6kB8llJQfHh7EeIpTXBbXKfC5Ea2A2WwDY6xrpX3JFnvfj6D4sVTIXyHtE

